package fail2.reset;

import android.app.*;
import android.app.admin.*;
import android.content.*;
import android.view.*;

//Activity for ask Admin

public class MainActivity extends Activity {

	@Override
	protected void onResume() {
		super.onResume();

		ComponentName adminComponent = new ComponentName(this, MyAdminReceiver.class);
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);

        if (!dpm.isAdminActive(adminComponent)) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
            startActivity(intent);
		}

	}}
