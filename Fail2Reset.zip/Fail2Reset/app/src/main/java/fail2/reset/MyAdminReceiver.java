package fail2.reset;

import android.app.admin.*;
import android.content.*;
import android.os.*;

public class MyAdminReceiver extends DeviceAdminReceiver {
    private static long lastFailedAttemptTime;

    @Override
    public void onPasswordFailed(Context context, Intent intent) {
        if (SystemClock.elapsedRealtime() - lastFailedAttemptTime < 10000) {
            ((DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE)).wipeData(0);
        } else {
            lastFailedAttemptTime = SystemClock.elapsedRealtime();
        }
    }
}
